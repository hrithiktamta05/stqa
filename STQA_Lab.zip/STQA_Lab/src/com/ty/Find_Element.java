package com.ty;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Find_Element {
	public static void main(String[] args) {
		System.setProperty("Webdriver.chrome.driver",
				"C:\\Users\\pcgir\\OneDrive\\Desktop\\stqa\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		WebElement ele = driver.findElement(By.id("email"));
		ele.sendKeys("giradkarpranu@gmail.com");
		WebElement ele2 = driver.findElement(By.id("pass"));
		ele2.sendKeys("Pranay@5321.");
		WebElement ele3 = driver.findElement(By.name("login")); 
		ele3.click(); 
		System.out.println("Login button clicked");
		
	}
}
