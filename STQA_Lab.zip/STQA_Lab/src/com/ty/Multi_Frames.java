package com.ty;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Multi_Frames {

	public static void main(String[] args) {
		System.setProperty("Webdriver.chrome.driver",
				"C:\\Users\\pcgir\\OneDrive\\Desktop\\stqa\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.guru99.com/test/guru99home/");
// navigates to the page consisting an iframe
		driver.manage().window().maximize();
		driver.switchTo().frame("a077aa5e");
		System.out.println("We are switch to the iframe");
		driver.findElement(By.xpath("html/body/a/img")).click();
//Clicks the iframe 
		System.out.println("*We are done*");
	}
}
