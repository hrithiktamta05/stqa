package com.ty;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class StqaPrac {
	public static void main(String[] args) {
		System.setProperty("Webdriver.chrome.driver", "C:\\Users\\pcgir\\OneDrive\\Desktop\\stqa\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.youtube.com/");
		
//		System.setProperty("Webdriver.gecko.driver", "C:\\Users\\pcgir\\OneDrive\\Desktop\\stqa\\geckodriver.exe");
//		WebDriver driver = new FirefoxDriver();
//		driver.get("https://www.youtube.com/");
		
		String title = driver.getTitle();
		System.out.println("Title is : "+title);
	}
}
