package regression;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Regression_RetryFailedCases implements IRetryAnalyzer {

	int noOfRetries = 0;
	int maximumRetries = 3;
	
	@Override
	public boolean retry(ITestResult result) {
		if(noOfRetries < maximumRetries) {
			System.out.println(result.getName()+" no. of entry is "+(noOfRetries+1));
			noOfRetries++;
			return true;
		}
		return false;
	}
	
	
}
