package regression;

import org.testng.Assert;

public class Test {

	@org.testng.annotations.Test
	public void validationRetry() {
		Assert.assertTrue(false);
	}
}
