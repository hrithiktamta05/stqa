package regression;


import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.IRetryAnalyzer;
import org.testng.annotations.ITestAnnotation;

public class Transform implements IAnnotationTransformer {
	
	public void transform(ITestAnnotation testAnnotation, Class arg1, Constructor arg2, Method arg3) {
		Class<? extends IRetryAnalyzer> retry = testAnnotation.getRetryAnalyzerClass();
		
		if(retry == null) {
			testAnnotation.setRetryAnalyzer(Regression_RetryFailedCases.class);
		}
		
	}

}
