//  Running TestNG Annotations:


package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNG1 {
	public String baseUrl = "https://www.google.com/";
	String driverPath = "E:\\C21134 Hrushikesh\\chromedriver\\chromedriver.exe";
	public WebDriver driver;
	@Test
	public void f() throws InterruptedException {
	System.out.println("Launching chrome browser");
	System.setProperty("Webdriver.chrome.driver", driverPath);
	driver = new ChromeDriver();
	driver.get(baseUrl);
	driver.findElement(By.name("q")).sendKeys("DES NMITD", Keys.ENTER);
	Thread.sleep(2000);
	 }


}
