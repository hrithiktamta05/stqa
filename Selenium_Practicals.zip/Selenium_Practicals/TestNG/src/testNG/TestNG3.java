package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNG3 {
	String actualTitle, expectedTitle;

	@BeforeTest
	public void launchBrowser() {
		System.out.println("launching Google chrome browser");
		System.setProperty("webdriver.chrome.driver",
				"D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/newtours/");
	}

	@Test
	public void verifyHomepageTitle() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String expectedTitle = "Welcome: Mercury Tours";
		String ActualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle);
	}

	@AfterTest
	public void terminateBrowser() {
		System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.close();
	}
}
