package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Validation_Test {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		String title =driver.getTitle(); // Check the validation of title
		System.out.println("title is" +title);
		System.out.println(driver.getCurrentUrl()); //Check the validation of URL
		// # Check the validation of the Search box is Visible are not.
		boolean status = driver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]")).isDisplayed();
		if(status){
		System.out.println("Search box is visible");
		} else {
		System.out.println("Search box is hidden");
		}


	}

}
