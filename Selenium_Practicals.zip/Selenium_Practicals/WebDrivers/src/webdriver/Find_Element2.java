package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Find_Element2 {

	public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
				//driver.get("https://www.google.com");
				driver.navigate().to("https://www.facebook.com/");
				WebElement el = driver.findElement(By.linkText("Forgotten password?"));
				el.click();
				System.out.println("Forgoten password? Clicked");

	}

}
