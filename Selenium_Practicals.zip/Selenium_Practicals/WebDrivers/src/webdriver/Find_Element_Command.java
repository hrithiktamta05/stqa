package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Find_Element_Command {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to("https://www.facebook.com/");
		WebElement el = driver.findElement(By.id("email"));
		el.sendKeys("hanchatesameer@gmail.com");
		WebElement el2 = driver.findElement(By.id("pass"));
		el2.sendKeys("123456");
		WebElement el3 = driver.findElement(By.name("login"));
		el3.click();
		System.out.println("Login button clicked");

	}

}
