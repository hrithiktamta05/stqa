package webdriver;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class List_Boxes {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.navigate().to("https://www.facebook.com/r.php?r=101");
		Select month = new Select(driver.findElement(By.id("month")));
		List<WebElement> gender = driver.findElements(By.name("sex"));
		int cnt = gender.size();
		System.out.println(cnt);
		for (int i = 0; i <= cnt - 1; i++)

		{
			String text = gender.get(i).getText();
			System.out.println(text);
			gender.get(i).click();
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
