package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		WebElement img = driver.findElement(By.xpath("//*[@id=\"passContainer\"]"));
		System.out.println(img.isDisplayed());
		System.out.println(img.isEnabled());
		System.out.println(img.isSelected());

	}

}
