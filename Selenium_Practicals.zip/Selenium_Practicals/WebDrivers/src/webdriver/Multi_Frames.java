package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Multi_Frames {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.guru99.com/test/guru99home/");
		
		driver.manage().window().maximize();
		driver.switchTo().frame("a0775aa5e");
		System.out.println("We are switch to iframe");
		
		driver.findElement(By.xpath("html/body/a/img")).click();
		
		System.out.println("We are done");

	}

}
