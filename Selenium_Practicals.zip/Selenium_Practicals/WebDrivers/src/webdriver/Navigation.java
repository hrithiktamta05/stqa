package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigation {

	public static void main(String[] args) {
		
		System.setProperty("Webdriver.chrome.driver","C:\\Users\\rushi\\OneDrive\\Desktop\\C21134_STQA\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				//driver.get("https://www.google.com");
				driver.navigate().to("https://www.google.com");
				driver.findElement(By.linkText("Images")).click();
				try {
				Thread.sleep(2000);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
				driver.navigate().back();
				try {
				Thread.sleep(1000);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
				System.out.println("back done........");
				driver.navigate().forward();
				try {
				Thread.sleep(1000);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
				System.out.println("Forward done........");
				driver.navigate().refresh();
				try {
				Thread.sleep(1000);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
				System.out.println("refresh done........");

	}

}
