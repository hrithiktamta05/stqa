package webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtton_TextBoxes {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\STQA\\Selenium\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to("file:///D:/STQA/Selenium/index.html");
		driver.findElement(By.xpath("/html/body/input[3]")).click();
		System.out.println("Sucessfully completed");
	}

}
