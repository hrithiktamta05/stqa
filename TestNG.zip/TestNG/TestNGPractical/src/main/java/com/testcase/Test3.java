package com.testcase;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class Test3 {
	String actualTitle, expectedTitle;
	WebDriver driver = new ChromeDriver();
	public void launchBrowser() {
		System.out.println("launching Google chrome browser");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\pcgir\\OneDrive\\Desktop\\stqa\\chromedriver.exe");
		
		driver.get("https://demo.guru99.com/test/newtours/");
	}

	@Test
	public void verifyHomepageTitle() {
		String expectedTitle = "Welcome: Mercury Tours";
		String ActualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle);
	}

	@AfterTest
	public void terminateBrowser() {
		driver.close();
		System.out.println("After test executed");
	}
}
