package com.testcase;

import org.testng.annotations.Test;

public class TestCase1 {

	@Test(priority = 2)
	public void logintest() {
		System.out.println("This is TestNG case 1.");
	}
	
	@Test(priority = 1,description = "This is an example testcase")
	public void logouttest() {
		System.out.println("This is TestNG case 2.");
	}
}
